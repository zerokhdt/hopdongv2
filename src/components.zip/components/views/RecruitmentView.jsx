import React, { useState, useMemo, useEffect } from 'react';
import { 
  UserSearch, Send, FileCheck, CheckCircle2, XCircle, 
  MessageSquare, Video, Star, Clock, Building2, UserCircle, 
  ExternalLink, ArrowRight, UserPlus, FileText, Search, 
  Filter, History, AlertTriangle, RotateCcw, Users, RefreshCw, X, Ban
} from 'lucide-react';
import { signInAnonymously, onAuthStateChanged, signInWithCustomToken } from 'firebase/auth';
import { auth } from '../../utils/firebase'; // Import từ file cấu hình mới
import { apiFetch } from '../../utils/api';
import { fetchCandidates, saveInterview, createAccessToken, updateCandidateStatus } from '../../utils/supabase-api';
import CandidatesTab from '../tabs/CandidatesTab';
import BranchManagementTab from '../tabs/BranchManagementTab';
import InterviewTab from '../tabs/InterviewTab';
import ReportTab from '../tabs/ReportTab';
import CandidateDetailModal from '../modals/CandidateDetailModal';
import Binterviewed from '../modals/Binterviewed';
import { generateMockCandidates } from '../../utils/mockGenerator';

/* global __initial_auth_token */
// Helper to convert Google Drive link to Preview link (dành cho iframe nếu cần)
const _getEmbedtableUrl = (url) => {
  if (!url) return '';
  if (url.includes('drive.google.com')) {
    let id = '';
    if (url.includes('id=')) {
      id = url.split('id=')[1].split('&')[0];
    } else if (url.includes('/file/d/')) {
      id = url.split('/file/d/')[1].split('/')[0];
    }
    if (id) return `https://drive.google.com/file/d/${id}/preview`;
  }
  return url;
};

export default function RecruitmentView({ userRole, branchId, employees: _employees, onSelectCandidate: _onSelectCandidate, subTab = 'recruitment-candidates' }) {
  const isAdmin = userRole === 'admin';
  const [user, setUser] = useState(null);
  // Map subTab to internal tab for candidate filtering
  const internalTab = subTab === 'recruitment-candidates' ? 'pipeline' :
                     subTab === 'recruitment-branch' ? 'monitoring' :
                     subTab === 'recruitment-interview' ? 'my-interviews' :
                     subTab === 'recruitment-report' ? 'completed' : subTab;
  const [interviewEnabled] = useState(false); // Tắt chức năng phỏng vấn
  
  // Trạng thái cho Modal (có thể là 'VIEW' hoặc 'EVALUATE')
  const [modalState, setModalState] = useState({ isOpen: false, candidate: null, mode: 'VIEW' });
  
  // Trạng thái bộ lọc
  const [searchTerm] = useState('');
  const [filterBranch, _setFilterBranch] = useState('');
  const [filterPosition, _setFilterPosition] = useState('');
  const [filterSalary, _setFilterSalary] = useState('');
  const [filterDate, _setFilterDate] = useState('');
  const [filterStatus, _setFilterStatus] = useState('');
  
  const [isSyncing, setIsSyncing] = useState(false);
  const [candidates, setCandidates] = useState(() => {
    const saved = localStorage.getItem('ace_recruitment_candidates_v1');
    return saved ? JSON.parse(saved) : [];
  });

  const handleMockCandidates = () => {
    if (window.confirm('Bạn có chắc chắn muốn nạp 100 ứng viên mẫu để demo tuyển dụng?')) {
      const mock = generateMockCandidates(100);
      setCandidates(mock);
      localStorage.setItem('ace_recruitment_candidates_v1', JSON.stringify(mock));
      alert('Đã tạo thành công 100 ứng viên mẫu!');
    }
  };

  // Fetch candidates from Supabase (replaces Google Sheet)
  const fetchLiveCandidates = async () => {
    setIsSyncing(true);
    try {
      const options = {};
      if (filterBranch) options.branch = filterBranch;
      
      const data = await fetchCandidates(options);
      console.log("Candidates from Supabase:", data);
      
      // Transform data to match existing format
      const transformedCandidates = data.map(candidate => ({
        id: candidate.id,
        rowIndex: candidate.row_index,
        name: candidate.full_name,
        position: candidate.position,
        phone: candidate.phone,
        email: candidate.email,
        branch: candidate.branch_assigned,
        status: candidate.status,
        cvUrl: candidate.cv_url,
        rawData: candidate.raw_data || {},
        createdAt: candidate.created_at,
        updatedAt: candidate.updated_at
      }));
      
      setCandidates(transformedCandidates);
    } catch (e) {
      console.error("Lỗi fetch candidates từ Supabase:", e);
      // Fallback logic could go here
    } finally {
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    fetchLiveCandidates(); // Fetch data when component mounts

    // Existing Auth setup
    const initAuth = async () => {
      try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
          await signInWithCustomToken(auth, __initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
      } catch (error) {
        console.error("Lỗi xác thực Firebase:", error);
      }
    };
    initAuth();
    const unsubscribe = onAuthStateChanged(auth, setUser);
    return () => unsubscribe();
  }, []);

  // Cập nhật candidate status (Supabase version)
  const handleAction = async (candidateId, action, extra = {}) => {
    if (!user) return;
    
    const c = candidates.find(can => can.id === candidateId);
    if (!c) return;

    const now = new Date().toISOString();

    try {
      // Logic cập nhật Local State (Rất quan trọng cho Demo mượt mà)
      const updateLocal = (id, newStatus, extraData) => {
        setCandidates(prev => {
          const updated = prev.map(can => {
            if (can.id === id) {
              return { 
                ...can, 
                status: newStatus, 
                ...extraData, 
                updatedAt: now,
                updated_at: now
              };
            }
            return can;
          });
          localStorage.setItem('ace_recruitment_candidates_v1', JSON.stringify(updated));
          return updated;
        });
      };

      if (action === 'SEND') {
        // Create access token for branch
        try {
          await createAccessToken({
            candidate_id: candidateId,
            branch_id: extra.branch,
            interviewer_email: extra.interviewer_email || '',
            expires_hours: 120 // 5 days
          });
        } catch (e) { console.warn("Supabase Access Token failed, only updating local state."); }
        
        await updateCandidateStatus(candidateId, 'SENT_TO_BRANCH', {
          branch_assigned: extra.branch,
          interviewer_email: extra.interviewer_email,
          sent_at: now
        }).catch(() => {});

        updateLocal(candidateId, 'SENT_TO_BRANCH', { branch: extra.branch, branch_assigned: extra.branch, interviewer_email: extra.interviewer_email });
        alert(`Đã gửi ứng viên cho chi nhánh ${extra.branch}.`);
      }
      else if (action === 'WITHDRAW') {
        await updateCandidateStatus(candidateId, 'PENDING', {
          branch_assigned: null,
          interviewer_email: null
        }).catch(() => {});
        updateLocal(candidateId, 'PENDING', { branch: null, branch_assigned: null });
      }
      else if (action === 'COMPLETE') {
        await saveInterview({
          candidate_id: candidateId,
          interviewer_email: extra.interviewer_email || c.interviewer_email,
          interview_date: extra.interview_date || now,
          technical_score: extra.technical_score,
          communication_score: extra.communication_score,
          attitude_score: extra.attitude_score,
          overall_score: extra.overall_score,
          decision: extra.decision,
          notes: extra.note
        }).catch(() => {});
        updateLocal(candidateId, 'COMPLETED', extra);
      }
      else if (action === 'SCHEDULE') {
        await updateCandidateStatus(candidateId, 'SENT_TO_BRANCH', {
           interview_date: extra.interview_date,
           note: `Chi nhánh hẹn phỏng vấn lúc: ${extra.interview_date}`
        }).catch(() => {});
        updateLocal(candidateId, 'SENT_TO_BRANCH', { interview_date: extra.interview_date });
      }
      else if (action === 'REJECT') {
        await updateCandidateStatus(candidateId, 'REJECTED', {
          reject_reason: extra.reason || 'Không đạt yêu cầu'
        }).catch(() => {});
        updateLocal(candidateId, 'REJECTED', { reject_reason: extra.reason });
      }
      
      // Refresh candidates list from server if possible
      fetchLiveCandidates();
      
    } catch (e) {
      console.error("Lỗi cập nhật:", e);
      alert(`Lỗi: ${e.message}`);
    }
  };

  const _getTimeStatus = (deadline) => {
    if (!deadline) return null;
    const diff = new Date(deadline) - new Date();
    if (diff < 0) return 'EXPIRED';
    if (diff < 12 * 60 * 60 * 1000) return 'URGENT';
    return 'NORMAL';
  };

  const _filteredCandidates = useMemo(() => {
    let list = candidates;
    
    // Lọc theo Tab
    if (internalTab === 'pipeline') {
      list = list.filter(c => c.status === 'PENDING');
    } else if (internalTab === 'monitoring') {
      list = list.filter(c => c.status === 'SENT_TO_BRANCH' || (c.status === 'COMPLETED' && c.interviewer !== 'HRM Admin'));
    } else if (internalTab === 'my-interviews') {
      if (isAdmin) {
        list = list.filter(c => c.interviewer === 'HRM Admin' || c.status === 'PENDING');
      } else {
        list = list.filter(c => (c.branch === branchId || c.interviewer === (branchId ? `Manager ${branchId}` : 'Manager')) && c.status === 'SENT_TO_BRANCH');
      }
    } else if (internalTab === 'completed') {
      list = list.filter(c => c.status === 'COMPLETED' || c.status === 'REJECTED');
    }

    // Lọc theo Search (Tên, ID)
    if (searchTerm) {
      list = list.filter(c => 
        c.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
        c.id?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Lọc theo Chi nhánh
    if (filterBranch) {
      list = list.filter(c => (c.branch || 'HEAD OFFICE') === filterBranch);
    }
    
    // Lọc theo Vị trí
    if (filterPosition) {
      list = list.filter(c => c.position?.toLowerCase().includes(filterPosition.toLowerCase()));
    }

    // Sắp xếp: Mới nhất lên đầu
    return [...list].sort((a, b) => {
      const dateA = new Date(a.updatedAt || a.createdAt || 0);
      const dateB = new Date(b.updatedAt || b.createdAt || 0);
      return dateB - dateA;
    });
  }, [candidates, internalTab, searchTerm, filterBranch, filterPosition, isAdmin, branchId]);

  const handleViewCandidate = (candidate, mode = 'VIEW') => {
    setModalState({ isOpen: true, candidate, mode });
  };

  // Render appropriate component based on subTab
  const renderContent = () => {
    const commonProps = { candidates, isAdmin, branchId, onViewDetail: handleViewCandidate };
    switch (subTab) {
      case 'recruitment-candidates':
        return <CandidatesTab {...commonProps} onMock={handleMockCandidates} />;
      case 'recruitment-branch':
        return <BranchManagementTab {...commonProps} />;
      case 'recruitment-interview':
        return <InterviewTab {...commonProps} />;
      case 'recruitment-report':
        return <ReportTab {...commonProps} />;
      default:
        return null;
    }
  };

  return (
    <div className="h-auto min-h-full flex flex-col bg-[#F2F4F7] pt-2 px-4 pb-4 lg:pt-3 lg:px-6 lg:pb-6">
      {renderContent()}

      {/* MODAL CHI TIẾT & ĐÁNH GIÁ */}
      {modalState.mode === 'B_interviewed' ? (
        <Binterviewed
          isOpen={modalState.isOpen}
          candidate={modalState.candidate}
          onClose={() => setModalState({ isOpen: false, candidate: null, mode: 'VIEW' })}
          disabledSubmit={!interviewEnabled && !isAdmin}
          onShowDetail={(candidate) => setModalState({ isOpen: true, candidate, mode: 'VIEW' })}
          onSubmit={(results) => {
            if (!interviewEnabled && !isAdmin) {
              alert('Chức năng phỏng vấn hiện đang tắt. Chỉ tài khoản admin có thể xem dữ liệu.');
              return;
            }
            handleAction(modalState.candidate.id, 'COMPLETE', {
              ...results,
              interviewer: isAdmin ? 'HRM Admin' : (branchId ? `Manager ${branchId}` : 'Manager'),
            });
            setModalState({ isOpen: false, candidate: null, mode: 'VIEW' });
          }}
        />
      ) : (
        <CandidateDetailModal
          isOpen={modalState.isOpen}
          candidate={modalState.candidate}
          mode={modalState.mode}
          isHRM={isAdmin}
          onClose={() => setModalState({ isOpen: false, candidate: null, mode: 'VIEW' })}
          onSubmitEval={(results) => {
            if (!interviewEnabled && !isAdmin) {
              alert('Chức năng phỏng vấn hiện đang tắt. Chỉ tài khoản admin có thể xem dữ liệu.');
              return;
            }
            handleAction(modalState.candidate.id, 'COMPLETE', {
              ...results,
              interviewer: isAdmin ? 'HRM Admin' : (branchId ? `Manager ${branchId}` : 'Manager'),
            });
            setModalState({ isOpen: false, candidate: null, mode: 'VIEW' });
          }}
          onAssign={(assignment) => {
            handleAction(modalState.candidate.id, 'SEND', assignment);
            setModalState({ isOpen: false, candidate: null, mode: 'VIEW' });
          }}
          onBranchAction={(action, extra) => {
            handleAction(modalState.candidate.id, action, extra);
          }}
        />
      )}
    </div>
  );
}
