import React, { useState } from 'react';
import { Download, Printer, Filter, Search, RefreshCw } from 'lucide-react';
import CandidateDetailModal from '../modals/CandidateDetailModal';
import { formatName, formatBranch, formatPosition } from '../../utils/formatters';
import { downloadCSV } from '../../utils/exportCsv';

const CandidatesTab = ({ candidates = [], isAdmin: _isAdmin = false, branchId: _branchId = '', onViewDetail, onMock }) => {
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleViewDetails = (candidate) => {
    if (onViewDetail) {
      onViewDetail(candidate);
    } else {
      setSelectedCandidate(candidate);
      setIsModalOpen(true);
    }
  };
  // Calculate stats from candidates
  const totalCandidates = candidates.length;
  const pendingCandidates = candidates.filter(c => c.status === 'PENDING').length;
  const sentCandidates = candidates.filter(c => c.status === 'SENT_TO_BRANCH').length;
  const completedCandidates = candidates.filter(c => c.status === 'COMPLETED').length;
  const rejectedCandidates = candidates.filter(c => c.status === 'REJECTED').length;

  // Mock source data - Sliced to 3 for compact list view
  const sourceData = [
    { name: 'LinkedIn', count: 1240, percentage: 65, color: 'bg-[#00288e]' },
    { name: 'Giới thiệu', count: 482, percentage: 35, color: 'bg-indigo-500' },
    { name: 'TopCV', count: 2109, percentage: 85, color: 'bg-cyan-500' },
  ];

  // Mock branch performance - Sliced to 3 for compact list view
  const branchPerformance = [
    { name: 'HCM - Quận 1', fillRate: 82, vacancies: 24, hires: 12, colorClass: 'bg-[#00288e]' },
    { name: 'Đà Nẵng - Hải Châu', fillRate: 95, vacancies: 8, hires: 9, colorClass: 'bg-emerald-500' },
    { name: 'Hà Nội - Ba Đình', fillRate: 45, vacancies: 18, hires: 4, colorClass: 'bg-amber-500' },
  ];

  // Mock interview pipeline - Sliced to 3 for compact list view
  const interviewPipeline = [
    { role: 'Product Designer', stage: 'Vòng cuối', candidates: 5, due: 'Hôm nay' },
    { role: 'Backend Dev', stage: 'Kiểm tra kỹ thuật', candidates: 9, due: 'Ngày mai' },
    { role: 'Marketing Lead', stage: 'Sàng lọc', candidates: 12, due: 'Tuần sau' },
  ];

  // History rows from actual candidates
  const historyRows = candidates.length > 0 ? candidates.map(candidate => ({
    name: formatName(candidate.name),
    email: candidate.email || 'no-email@example.com',
    position: formatPosition(candidate.position),
    branch: formatBranch(candidate.branch || 'Hội Sở'),
    result: candidate.status === 'COMPLETED' ? 'Nhận việc' : 
            candidate.status === 'REJECTED' ? 'Từ chối' : 
            candidate.status === 'SENT_TO_BRANCH' ? 'Phỏng vấn' : 'Đang chờ',
    date: candidate.createdAt ? new Date(candidate.createdAt).toLocaleDateString('vi-VN', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Hôm nay',
    resultColor: candidate.status === 'COMPLETED' ? 'green' :
                 candidate.status === 'REJECTED' ? 'red' :
                 candidate.status === 'SENT_TO_BRANCH' ? 'blue' : 'slate'
  })) : [
    // Fallback mock data if candidates array is empty for visual testing
    { name: 'Lê Đức Việt', email: 'leducviet97@gmail.com', position: 'Part-time teacher', branch: 'ACE An Sương', result: 'Phỏng vấn', date: '11 thg 4, 2023', resultColor: 'blue', phone: '0339839793', gender: 'Nam', university: 'Cao đẳng Viễn Đông', major: 'Ngành Tiếng Anh', cvLink: 'https://drive.google.com/open?id=12_wyntGZNz7NlX-KrV-gqt7HZYh3WOxR', experience: 4, dob: '07/07/1997', address: 'D16/5J/17 Võ Văn Vân, Ấp 4B, Xã Vĩnh Lộc B', expectedSalary: '4-5 triệu', status: 'SENT_TO_BRANCH' },
    { name: 'Đàm Việt Cường', email: 'vcdvcuong@gmail.com', position: 'Full-time teacher', branch: 'Hội Sở', result: 'Phỏng vấn', date: '18 thg 1, 2024', resultColor: 'blue', phone: '0866532415', gender: 'Nam', university: 'Trường Đại học KHXH&NV', major: 'Ngôn ngữ Anh', cvLink: 'https://drive.google.com/open?id=18IG93_MbbfOd0_BVCLxnvyvTnL3We0XP', experience: 0.5, dob: '19/08/2000', address: '285/17 Phan Văn Hớn, Quận 12, TPHCM', expectedSalary: '8.000.000', status: 'SENT_TO_BRANCH' },
    { name: 'Nguyễn Xuân Trúc', email: 'xtruc10601@gmail.com', position: 'Invited Teacher', branch: 'ACE An Sương', result: 'Từ chối', date: '01 thg 1, 2025', resultColor: 'red', phone: '0708362943', gender: 'Nữ', university: 'Hoa Sen University', major: 'English Linguistics', cvLink: 'https://drive.google.com/open?id=1R_EBL3uJs6v5KpOT4t9IsALlspDumQbC', experience: 5, dob: '11/06/2001', address: '48/5C Giang Cu Vong Street, District 12', expectedSalary: 'Thương lượng', status: 'REJECTED' },
  ];

  return (
    <div className="h-full flex flex-col bg-[#F2F4F7] text-gray-900 pt-2 px-4 pb-4 lg:pt-3 lg:px-6 lg:pb-6 overflow-y-auto font-sans">
      
      {/* Detail Modal (Only if standalone) */}
      {!onViewDetail && (
        <CandidateDetailModal 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)} 
          candidate={selectedCandidate} 
        />
      )}
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 shrink-0">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 tracking-tight">Trung tâm tuyển dụng</h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input 
              type="text" 
              placeholder="Tìm kiếm ứng viên..." 
              className="pl-9 pr-4 py-2.5 bg-[#f2f4f6] text-[15px] font-medium leading-relaxed text-gray-900 rounded-lg outline-none focus:bg-white focus:ring-2 focus:ring-[#00288e] transition-all w-64 border border-transparent focus:border-[#00288e]/20"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-200 text-gray-700 rounded-lg font-medium text-sm hover:bg-gray-50 transition-colors shadow-sm">
            <Filter size={16} />
            Lọc
          </button>
          <button 
            onClick={() => downloadCSV(historyRows, 'danh_sach_ung_vien')}
            className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-br from-emerald-600 to-emerald-700 text-white rounded-lg font-medium text-sm hover:opacity-90 transition-opacity shadow-sm"
          >
            <Download size={16} />
            Xuất CSV
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 lg:gap-6 mb-6 shrink-0">
        <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm flex flex-col justify-between transition-shadow hover:shadow-md">
          <div className="flex justify-between items-start">
            <span className="text-sm font-semibold text-gray-500">Tổng ứng viên</span>
            <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-md text-sm font-semibold">+12%</span>
          </div>
          <div className="mt-3 text-3xl font-bold text-gray-900">{totalCandidates || 1284}</div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm flex flex-col justify-between transition-shadow hover:shadow-md">
          <div className="flex justify-between items-start">
            <span className="text-sm font-semibold text-gray-500">Chờ xử lý</span>
            <span className="bg-amber-50 text-amber-700 border border-amber-200 px-2 py-0.5 rounded-md text-sm font-semibold">+8%</span>
          </div>
          <div className="mt-3 text-3xl font-bold text-gray-900">{pendingCandidates || 45}</div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm flex flex-col justify-between transition-shadow hover:shadow-md">
          <div className="flex justify-between items-start">
            <span className="text-sm font-semibold text-gray-500">Đang phỏng vấn</span>
            <span className="bg-blue-50 text-blue-700 border border-blue-200 px-2 py-0.5 rounded-md text-sm font-semibold">+24%</span>
          </div>
          <div className="mt-3 text-3xl font-bold text-gray-900">{sentCandidates || 128}</div>
        </div>
        <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm flex flex-col justify-between transition-shadow hover:shadow-md">
          <div className="flex justify-between items-start">
            <span className="text-sm font-semibold text-gray-500">Đã chốt / Loại</span>
            <span className="bg-gray-100 text-gray-700 border border-gray-200 px-2 py-0.5 rounded-md text-sm font-semibold">Đã đóng</span>
          </div>
          <div className="mt-3 text-3xl font-bold text-gray-900">{completedCandidates + rejectedCandidates || 942}</div>
        </div>
      </div>

      {/* FULL WIDTH TABLE: Danh sách ứng viên (Chiếm không gian chính) */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden flex flex-col mb-6 shrink-0">
        <div className="px-6 py-5 border-b border-gray-200 flex justify-between items-center bg-white z-10">
          <h3 className="text-base font-medium text-gray-900">Danh sách nhân sự / Ứng viên</h3>
          <div className="flex gap-2">
            <button onClick={onMock} className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors text-amber-500" title="Mock 100 UV">
              <RefreshCw size={18} />
            </button>
            <button className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors text-gray-500">
              <Download size={18} />
            </button>
            <button className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors text-gray-500">
              <Printer size={18} />
            </button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-slate-50/50 border-b border-gray-200">
                <th className="px-6 py-4 text-sm font-bold text-gray-500 w-16 text-center">STT</th>
                <th className="px-6 py-4 text-sm font-bold text-gray-500">Họ và tên</th>
                <th className="px-6 py-4 text-sm font-bold text-gray-500">Vị trí ứng tuyển</th>
                <th className="px-6 py-4 text-sm font-bold text-gray-500">Chi nhánh</th>
                <th className="px-6 py-4 text-sm font-bold text-gray-500 text-center">Ngày nộp</th>
                <th className="px-6 py-4 text-sm font-bold text-gray-500">Trạng thái</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {historyRows.map((row, idx) => (
                <tr key={idx} className="hover:bg-blue-50/30 transition-colors group">
                  <td className="px-6 py-4 text-sm text-gray-400 text-center">{idx + 1}</td>
                  <td className="px-6 py-4">
                    <div 
                      className="text-[15px] font-semibold text-gray-900 leading-relaxed cursor-pointer hover:text-[#00288e] hover:underline underline-offset-2 transition-all"
                      onClick={() => handleViewDetails(candidates[idx])}
                    >
                      {row.name}
                    </div>
                    <div className="text-sm text-gray-500 leading-relaxed">{row.email}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-[#00288e] font-medium leading-relaxed">
                    {row.position}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 leading-relaxed">{row.branch}</td>
                  <td className="px-6 py-4 text-sm text-gray-600 leading-relaxed text-center">{row.date}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <span className={`inline-flex items-center px-2 py-1 rounded-md text-sm font-semibold ${
                        row.resultColor === 'green' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                        row.resultColor === 'red' ? 'bg-rose-50 text-rose-600 border border-rose-100' :
                        row.resultColor === 'blue' ? 'bg-blue-50 text-blue-600 border border-blue-100' :
                        'bg-amber-50 text-amber-600 border border-amber-100'
                      }`}>
                        {row.result}
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Footer Phân trang */}
        <div className="p-4 border-t border-gray-200 bg-white flex justify-between items-center">
          <span className="text-sm text-gray-500">Hiển thị 1 đến {historyRows.length} của 150</span>
          <div className="flex gap-1">
            <button className="px-3 py-2 text-sm font-medium text-gray-500 hover:bg-gray-100 rounded-md transition-colors">Trang trước</button>
            <button className="px-3 py-2 text-sm font-medium bg-[#00288e] text-white rounded-md">1</button>
            <button className="px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-md transition-colors">2</button>
            <button className="px-3 py-2 text-sm font-medium text-gray-500 hover:bg-gray-100 rounded-md transition-colors">Trang sau</button>
          </div>
        </div>
      </div>

      {/* BOTTOM WIDGETS: 3 Columns - Compact List View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 shrink-0 pb-6">
        
        {/* 1. Lịch phỏng vấn */}
        <div className="bg-white p-5 rounded-xl shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)] border border-gray-100">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-[14px] font-semibold text-gray-900">Lịch phỏng vấn sắp tới</h3>
            <button className="text-[#00288e] text-sm font-medium hover:underline">Xem tất cả</button>
          </div>
          <div className="flex flex-col">
            {interviewPipeline.map((pipe, idx) => (
              <div key={idx} className="flex justify-between items-center py-2.5 border-b border-gray-50 last:border-0">
                <div className="min-w-0 pr-4">
                  <div className="text-[15px] font-medium text-gray-900 leading-relaxed truncate">{pipe.role}</div>
                  <div className="text-sm text-gray-500 leading-relaxed truncate">{pipe.stage} • {pipe.candidates} ứng viên</div>
                </div>
                <span className={`shrink-0 px-2 py-1 text-sm font-semibold rounded-md ${pipe.due === 'Hôm nay' ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-gray-100 text-gray-600 border border-gray-200'}`}>
                  {pipe.due}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* 2. Nguồn tuyển dụng */}
        <div className="bg-white p-5 rounded-xl shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)] border border-gray-100">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-[14px] font-semibold text-gray-900">Hiệu suất nguồn CV</h3>
            <span className="text-sm text-gray-400">Tuần này</span>
          </div>
          <div className="flex flex-col">
            {sourceData.map((source, idx) => (
              <div key={idx} className="flex items-center py-2.5 border-b border-gray-50 last:border-0">
                <div className="w-20 shrink-0">
                  <div className="text-[15px] font-medium text-gray-900 leading-relaxed truncate">{source.name}</div>
                  <div className="text-sm text-gray-500 leading-relaxed">{source.count} CV</div>
                </div>
                <div className="flex-1 px-3">
                  <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
                    <div className={`${source.color} h-full`} style={{ width: `${source.percentage}%` }}></div>
                  </div>
                </div>
                <div className="w-10 shrink-0 text-right text-sm font-semibold text-gray-600">
                  {source.percentage}%
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 3. Hiệu suất chi nhánh */}
        <div className="bg-white p-5 rounded-xl shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)] border border-gray-100">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-[14px] font-semibold text-gray-900">Tỷ lệ lấp đầy chi nhánh</h3>
            <span className="text-sm text-gray-400">Tháng này</span>
          </div>
          <div className="flex flex-col">
            {branchPerformance.map((branch, idx) => (
              <div key={idx} className="flex justify-between items-center py-2.5 border-b border-gray-50 last:border-0">
                <div className="min-w-0 pr-4">
                  <div className="text-[15px] font-medium text-gray-900 leading-relaxed truncate">{branch.name}</div>
                  <div className="text-sm text-gray-500 leading-relaxed truncate">{branch.vacancies} trống • Đã tuyển {branch.hires}</div>
                </div>
                <div className="shrink-0 flex items-center gap-2">
                  <span className="text-[15px] font-semibold text-[#00288e] leading-relaxed">{branch.fillRate}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default CandidatesTab;
