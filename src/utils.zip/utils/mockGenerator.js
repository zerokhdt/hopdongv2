export const generateMockEmployees = (count = 300) => {
  const firstNames = ['Nguyễn', 'Trần', 'Lê', 'Phạm', 'Hoàng', 'Huỳnh', 'Phan', 'Vũ', 'Võ', 'Đặng', 'Bùi', 'Đỗ', 'Hồ', 'Ngô', 'Dương', 'Lý'];
  const middleNames = ['Văn', 'Thị', 'Hoàng', 'Minh', 'Anh', 'Thanh', 'Đức', 'Quốc', 'Kim', 'Ngọc', 'Hồng', 'Tuyết'];
  const lastNames = ['Anh', 'Bình', 'Chi', 'Dũng', 'Em', 'Hùng', 'Hòa', 'Hồng', 'Hương', 'Khánh', 'Liên', 'Lâm', 'Mai', 'Nam', 'Nghĩa', 'Phúc', 'Quân', 'Sơn', 'Tâm', 'Thảo', 'Thắng', 'Trang', 'Tuyết', 'Vinh', 'Xuân', 'Yến'];
  
  const positions = [
    'Quản lý chi nhánh',
    'Giáo viên Fulltime',
    'Giáo viên Part-time',
    'Bảo vệ - Fulltime',
    'Tư vấn viên',
    'Kế toán chi nhánh',
    'Tạp vụ',
    'IT Support',
    'Marketing Executive'
  ];

  const departments = [
    'ACE AN SƯƠNG',
    'ACE PHAN VĂN HỚN',
    'ACE HÀ HUY GIÁP',
    'ACE LÊ VĂN KHƯƠNG',
    'TRỤ SỞ CHÍNH',
    'ACE LÊ LỢI',
    'ACE TRUNG MỸ TÂY',
    'ACE THỚI AN'
  ];

  const getRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];
  
  const formatDate = (date) => {
    return date.toISOString().split('T')[0];
  };

  const mockData = [];
  const now = new Date();

  for (let i = 1; i <= count; i++) {
    const firstName = getRandom(firstNames);
    const middleName = getRandom(middleNames);
    const lastName = getRandom(lastNames);
    const name = `${firstName} ${middleName} ${lastName}`;
    
    // Random dates
    const startYear = 2021 + Math.floor(Math.random() * 4); // 2021-2024
    const startMonth = Math.floor(Math.random() * 12);
    const startDay = Math.floor(Math.random() * 28) + 1;
    const startDate = new Date(startYear, startMonth, startDay);
    
    const contractDate = new Date(startDate);
    contractDate.setMonth(contractDate.getMonth() + 2); // Contract 2 months after start
    
    const renewDate = new Date(now);
    // Spread renewal dates across -30 to +90 days for RCC testing
    const offsetDays = Math.floor(Math.random() * 120) - 30; 
    renewDate.setDate(now.getDate() + offsetDays);

    const dob = new Date(1985 + Math.floor(Math.random() * 20), Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1);

    mockData.push({
      id: `EMP-${1000 + i}`,
      name: name.toLowerCase(), // Store lowercase to match the app's casing logic
      position: getRandom(positions).toLowerCase(),
      department: getRandom(departments),
      startDate: formatDate(startDate),
      contractDate: formatDate(contractDate),
      renewDate: formatDate(renewDate),
      email: `${lastName.toLowerCase()}${i}@example.com`,
      phone: `09${Math.floor(10000000 + Math.random() * 90000000)}`,
      status: 'active',
      dob: formatDate(dob),
      cccd: `${Math.floor(100000000000 + Math.random() * 900000000000)}`,
      salary: 7000000 + Math.floor(Math.random() * 10000000),
      pdf_url: Math.random() > 0.2 ? 'yes' : '',
      checklist_status: Math.random() > 0.1,
      avatar_url: `https://i.pravatar.cc/150?u=${i}`
    });
  }

  return mockData;
};

export const generateMockContracts = (employees, count = 100) => {
  const WORKFLOW_STAGES = [
    { id: 1, label: 'Ký tay & Upload', color: 'indigo' },
    { id: 2, label: 'Lãnh đạo phê duyệt', color: 'blue' },
    { id: 3, label: 'Hoàn tất & Lưu trữ', color: 'emerald' }
  ];

  const getRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];
  
  const formatDate = (date) => {
    return date.toISOString().split('T')[0];
  };

  const mockContracts = [];
  const now = new Date();

  // Pick random employees to have contracts
  const shuffledEmployees = [...employees].sort(() => 0.5 - Math.random());
  const targetEmployees = shuffledEmployees.slice(0, Math.min(count, employees.length));

  targetEmployees.forEach((emp, i) => {
    const stage = Math.floor(Math.random() * 3) + 1; // 1, 2, or 3
    const status = stage === 3 ? 'COMPLETED' : 'IN_PROGRESS';
    
    const submissionDate = new Date(emp.startDate);
    submissionDate.setDate(submissionDate.getDate() + 7);
    
    const signingDate = stage >= 2 ? new Date(submissionDate) : null;
    if (signingDate) signingDate.setDate(signingDate.getDate() + 3);

    mockContracts.push({
      id: `CONTRACT-${2000 + i}`,
      employeeId: emp.id,
      employeeName: emp.name,
      branch: emp.department,
      position: emp.position,
      soHd: `HĐLD-${emp.id.split('-')[1]}`,
      workflowStage: stage,
      workflowStatus: status,
      submissionDate: formatDate(submissionDate),
      signingDate: signingDate ? formatDate(signingDate) : null,
      ghi_chu: `Dữ liệu mẫu cho quy trình ${emp.name}`,
      auditTrail: [
        { time: formatDate(submissionDate), action: 'Khởi tạo quy trình', user: 'Admin' }
      ]
    });
  });

  return mockContracts;
};

export const generateMockCandidates = (count = 100) => {
  const firstNames = ['Nguyễn', 'Trần', 'Lê', 'Phạm', 'Hoàng', 'Huỳnh', 'Phan', 'Vũ', 'Võ', 'Đặng', 'Bùi', 'Đỗ', 'Hồ', 'Ngô', 'Dương', 'Lý'];
  const middleNames = ['Văn', 'Thị', 'Hoàng', 'Minh', 'Anh', 'Thanh', 'Đức', 'Quốc', 'Kim', 'Ngọc', 'Hồng', 'Tuyết'];
  const lastNames = ['Anh', 'Bình', 'Chi', 'Dũng', 'Em', 'Hùng', 'Hòa', 'Hồng', 'Hương', 'Khánh', 'Liên', 'Lâm', 'Mai', 'Nam', 'Nghĩa', 'Phúc', 'Quân', 'Sơn', 'Tâm', 'Thảo', 'Thắng', 'Trang', 'Tuyết', 'Vinh', 'Xuân', 'Yến'];
  
  const positions = [
    'Giáo viên Fulltime',
    'Giáo viên Part-time',
    'Tư vấn viên',
    'Kế toán chi nhánh',
    'Marketing Executive',
    'Hành chính HR',
    'Product Designer',
    'Backend Developer'
  ];

  const branches = [
    'ACE AN SƯƠNG',
    'ACE PHAN VĂN HỚN',
    'ACE HÀ HUY GIÁP',
    'ACE LÊ VĂN KHƯƠNG',
    'TRỤ SỞ CHÍNH',
    'ACE LÊ LỢI',
    'ACE TRUNG MỸ TÂY',
    'ACE THỚI AN'
  ];

  const statuses = ['PENDING', 'SENT_TO_BRANCH', 'COMPLETED', 'REJECTED'];

  const getRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];
  
  const mockCandidates = [];
  const now = new Date();

  for (let i = 1; i <= count; i++) {
    const name = `${getRandom(firstNames)} ${getRandom(middleNames)} ${getRandom(lastNames)}`;
    const status = getRandom(statuses);
    const branch = status === 'PENDING' ? null : getRandom(branches);
    
    const createdAt = new Date(now);
    createdAt.setDate(now.getDate() - Math.floor(Math.random() * 30));

    mockCandidates.push({
      id: `CAN-${5000 + i}`,
      name: name.toLowerCase(),
      position: getRandom(positions).toLowerCase(),
      phone: `09${Math.floor(10000000 + Math.random() * 90000000)}`,
      email: `${name.split(' ').pop().toLowerCase()}${i}@gmail.com`,
      branch: branch,
      status: status,
      cvUrl: 'https://drive.google.com/file/d/1demo-cv-id/view?usp=sharing',
      createdAt: createdAt.toISOString(),
      updatedAt: new Date().toISOString(),
      expectedSalary: `${Math.floor(Math.random() * 10) + 5}.000.000`,
      experience: Math.floor(Math.random() * 5) + 0.5,
      gender: Math.random() > 0.5 ? 'Nam' : 'Nữ'
    });
  }

  return mockCandidates;
};
