
export const generateDemoData = () => {
  const branches = [
    'TRUNG MỸ TÂY', 'NGUYỄN ẢNH THỦ', 'QUANG TRUNG', 'TÔ KÝ', 
    'LÊ VĂN KHƯƠNG', 'HÀ HUY GIÁP', 'VƯỜN LÀI', 'THẠNH XUÂN', 
    'TRẦN HƯNG ĐẠO', 'NGUYỄN VĂN QUÁ'
  ];

  const positions = [
    'Quản lý chi nhánh', 'Trưởng bộ phận văn phòng', 'Trưởng bộ phận chất lượng',
    'Nhân viên Full-time', 'Trợ giảng (TA)', 'Giáo viên nước ngoài', 'Giáo viên thỉnh giảng'
  ];

  const candidateSources = ['LinkedIn', 'Facebook', 'Giới thiệu', 'Trang tuyển dụng', 'Bảng tin việc làm'];
  const rejectionReasons = ['Kinh nghiệm chưa phù hợp', 'Kỳ vọng lương cao', 'Kỹ năng tiếng Anh yếu', 'Thời gian không linh hoạt', 'Không đạt bài test chuyên môn'];
  const firstNames = ['Nguyễn', 'Trần', 'Lê', 'Phạm', 'Hoàng', 'Phan', 'Vũ', 'Đặng', 'Bùi', 'Đỗ'];
  const middleNames = ['Văn', 'Thị', 'Hữu', 'Đức', 'Minh', 'Thanh', 'Quốc', 'Ngọc', 'Kim', 'Anh'];
  const lastNames = ['An', 'Bình', 'Chi', 'Dũng', 'Em', 'Giang', 'Hương', 'Hải', 'Khánh', 'Linh', 'Minh', 'Nam', 'Oanh', 'Phúc', 'Quang', 'Sơn', 'Tuấn', 'Vinh', 'Xuân', 'Yến'];

  const getRandomItem = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const getRandomName = () => `${getRandomItem(firstNames)} ${getRandomItem(middleNames)} ${getRandomItem(lastNames)}`;
  const getRandomDate = (start, end) => {
    const d = new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
    return d.toISOString().split('T')[0];
  };

  // Sample PDF URL for demo bypass
  const SAMPLE_CV_URL = "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf";

  // 1. Generate 300 Employees
  const employees = [];
  const createEmployee = (branch, position, hireDate) => {
    const id = `emp-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    const name = getRandomName();
    const gender = Math.random() > 0.5 ? 'Nam' : 'Nữ';
    
    return {
      id,
      name,
      department: branch,
      position,
      status: 'active',
      phone: `09${Math.floor(10000000 + Math.random() * 90000000)}`,
      email: `${name.split(' ').pop().toLowerCase()}.${id.slice(-4)}@ace.edu.vn`,
      personalEmail: `${name.split(' ').pop().toLowerCase()}@gmail.com`,
      dob: getRandomDate(new Date(1985, 0, 1), new Date(2003, 11, 31)),
      title: gender,
      nationality: 'Việt Nam',
      cccd: Math.floor(100000000000 + Math.random() * 900000000000).toString(),
      cccd_date: getRandomDate(new Date(2015, 0, 1), new Date(2023, 0, 1)),
      cccd_place: 'Cục CS QLHC về TTXH',
      address: `${Math.floor(Math.random() * 500) + 1} Đường số ${Math.floor(Math.random() * 50) + 1}, Q.12, TP. HCM`,
      startDate: hireDate,
      probationDate: hireDate,
      contractDate: getRandomDate(new Date(2023, 0, 1), new Date()),
      renewDate: getRandomDate(new Date(2026, 0, 1), new Date(2027, 0, 1)),
      salary: (5 + Math.floor(Math.random() * 30)) * 1000000,
      hasInsurance: Math.random() > 0.3 ? 'Có' : 'Không',
      insuranceAgency: 'BHXH TP. HCM',
      documentStatus: Math.random() > 0.2 ? 'Đủ' : 'Thiếu',
      avatar_url: `https://i.pravatar.cc/150?u=${id}`,
      pdf_url: SAMPLE_CV_URL,
      education: getRandomItem(['Đại học', 'Cao đẳng', 'Thạc sĩ']),
      major: getRandomItem(['Sư phạm tiếng Anh', 'Ngôn ngữ Anh', 'Quản trị kinh doanh', 'Kế toán']),
      pedagogyCert: Math.random() > 0.4 ? 'Đã có' : 'Đang cập nhật'
    };
  };

  branches.forEach(branch => {
    employees.push(createEmployee(branch, 'Quản lý chi nhánh', '2023-01-01'));
    employees.push(createEmployee(branch, 'Trưởng bộ phận văn phòng', '2023-02-15'));
    employees.push(createEmployee(branch, 'Trưởng bộ phận chất lượng', '2023-03-10'));
    
    const ftCount = 3 + Math.floor(Math.random() * 3);
    for (let i = 0; i < ftCount; i++) {
        employees.push(createEmployee(branch, 'Nhân viên Full-time', '2023-05-20'));
    }
  });

  while (employees.length < 300) {
    employees.push(createEmployee(
      getRandomItem(branches), 
      getRandomItem(['Trợ giảng (TA)', 'Giáo viên nước ngoài', 'Giáo viên thỉnh giảng']),
      '2024-01-15'
    ));
  }

  // 2. Generate 180 Candidates
  const candidates = [];
  
  // 100 new candidates in April (Month 4)
  const aprilStatuses = ['Pending', 'Interviewing', 'Sent', 'Rejected'];
  for (let i = 0; i < 100; i++) {
    const status = i < 40 ? 'Pending' : getRandomItem(aprilStatuses);
    const id = `can-4-${i}`;
    const name = getRandomName();
    const branch = getRandomItem(branches);
    
    candidates.push({
      id,
      name,
      position_name: getRandomItem(positions),
      status: status,
      applied_date: `2026-04-${Math.floor(Math.random() * 18) + 1}`,
      branch_id: branch,
      desiredBranch: branch,
      source: getRandomItem(candidateSources),
      phone: `09${Math.floor(10000000 + Math.random() * 90000000)}`,
      email: `${name.split(' ').pop().toLowerCase()}${i}@gmail.com`,
      rejection_reason: status === 'Rejected' ? getRandomItem(rejectionReasons) : null,
      notes: status === 'Sent' ? 'Hồ sơ mới đạt, chờ phỏng vấn chi nhánh.' : 'Hồ sơ tiềm năng.',
      avatar_url: `https://i.pravatar.cc/150?u=${id}`,
      pdf_url: SAMPLE_CV_URL,
      experience: `${Math.floor(Math.random() * 5) + 1} năm kinh nghiệm`,
      title: Math.random() > 0.5 ? 'Nam' : 'Nữ',
      address: `Quận ${Math.floor(Math.random() * 12) + 1}, TP. HCM`
    });
  }

  // 80 processed candidates in March (Month 3)
  const marchStatuses = ['Rejected', 'Interviewing', 'Sent', 'COMPLETED'];
  for (let i = 0; i < 80; i++) {
    const status = getRandomItem(marchStatuses);
    const id = `can-3-${i}`;
    const name = getRandomName();
    const branch = getRandomItem(branches);
    
    candidates.push({
      id,
      name,
      position_name: getRandomItem(positions),
      status: status,
      applied_date: `2026-03-${Math.floor(Math.random() * 28) + 1}`,
      branch_id: branch,
      desiredBranch: branch,
      source: getRandomItem(candidateSources),
      phone: `09${Math.floor(10000000 + Math.random() * 90000000)}`,
      email: `${name.split(' ').pop().toLowerCase()}${i}_old@gmail.com`,
      rejection_reason: status === 'Rejected' ? getRandomItem(rejectionReasons) : null,
      notes: status === 'COMPLETED' ? 'Đã nhận việc.' : 'Đã phản hồi.',
      avatar_url: `https://i.pravatar.cc/150?u=${id}`,
      pdf_url: SAMPLE_CV_URL,
      title: Math.random() > 0.5 ? 'Nam' : 'Nữ'
    });
  }

  // 3. Generate 50 Personnel Movements
  const movements = [];
  for (let i = 0; i < 50; i++) {
    movements.push({
      id: `mov-${i}`,
      employeeName: getRandomName(),
      type: getRandomItem(['Đề xuất tăng lương', 'Điều chuyển công tác', 'Khen thưởng', 'Kỷ luật']),
      date: `2026-03-${Math.floor(Math.random() * 28) + 1}`,
      status: getRandomItem(['Đã duyệt', 'Đang chờ', 'Từ chối']),
      branch: getRandomItem(branches),
      details: 'Ghi chú demo chuyển động nhân sự hệ thống.'
    });
  }

  const positionMappings = {
    'Quản lý chi nhánh': 'Full bộ (HĐ+PL+CK)',
    'Trưởng bộ phận văn phòng': 'HĐLĐ + Phụ lục',
    'Trưởng bộ phận chất lượng': 'HĐLĐ + Phụ lục',
    'Nhân viên Full-time': 'HĐLĐ + Phụ lục',
    'Trợ giảng (TA)': 'Thỏa thuận CV',
    'Giáo viên nước ngoài': 'Cam kết + HĐLĐ',
    'Giáo viên thỉnh giảng': 'Thỏa thuận CV'
  };

  return { 
    employees, 
    candidates, 
    branches,
    movements,
    positionMappings,
    colorConfig: {
      statuses: { 'TODO': 'slate', 'IN_PROGRESS': 'blue', 'DONE': 'green', 'CANCELLED': 'red' },
      groups: {
        'TRUNG MỸ TÂY': 'blue',
        'NGUYỄN ẢNH THỦ': 'orange',
        'QUANG TRUNG': 'purple',
        'TÔ KÝ': 'pink',
        'LÊ VĂN KHƯƠNG': 'indigo',
        'HÀ HUY GIÁP': 'emerald',
        'VƯỜN LÀI': 'rose',
        'THẠNH XUÂN': 'cyan',
        'TRẦN HƯNG ĐẠO': 'amber',
        'NGUYỄN VĂN QUÁ': 'slate'
      }
    }
  };
};
